// 22080932d ZHENG Kunteng, 22095248d CHENG Kai Yin

import express from 'express';
import session from 'express-session';
import mongostore from 'connect-mongo';
import client from './dbclient.js';
import login from './login.js';

const app = express();

app.use(express.urlencoded({ extended: true }));

app.use(
  session({
    secret: '22080932d_22095248d_project',
    resave: false,
    saveUninitialized: true,
    cookie: { httpOnly: true },
    store: mongostore.create({
      client,
      dbName: 'projectdb',
      collectionName: 'session',
    }),
  })
);

// apply login route module to the path /auth for all HTTP methods
app.use('/auth', login);

app.get('/', (req, res) => {
  if (req.session.logged) {
    res.redirect('/user-profile.html');
  } else {
    res.redirect('/login.html');
  }
});

app.use('/', express.static('static'));

app.listen(8080, () => {
  const currentDate = new Date().toLocaleDateString('en-US', { timeZone: 'Asia/Hong_Kong' });
  const currentTime = new Date().toLocaleTimeString('en-US', { timeZone: 'Asia/Hong_Kong' });
  console.log(`Current date and time: ${currentDate}, ${currentTime}`);
  console.log('Server started at http://127.0.0.1:8080');
});
/*
import express from 'express';
import bodyParser from 'body-parser';
import multer from 'multer';
import fs from 'fs/promises';
import session from 'express-session';
import mongostore from 'connect-mongo';
import client from './dbclient.js';
import login from './login.js';
import { validate_user, update_user, fetch_user, userid_exist } from './userdb.js';

const app = express();
//app.use(express.json());
app.use(bodyParser.json());
app.use(express.urlencoded({ extended: true }));

const users = new Map();
const upload = multer({ dest: './uploaded' });


app.use(
  session({
    secret: '22080932d_22095248d_project',
    resave: false,
    saveUninitialized: true,
    cookie: { httpOnly: true },
    store: mongostore.create({
      client,
      dbName: 'projectdb',
      collectionName: 'session',
    }),
  })
);

// apply login route module to the path /auth for all HTTP methods
app.use('/auth', login);

app.get('/', (req, res) => {
  if (req.session.logged) {
    res.redirect('/user-profile.html');
  } else {
    res.redirect('/login.html');
  }
});

app.post('/profile', upload.none(), async function (req, res) {
  try {
    console.log(req.files);
    console.log(req.body);

    //const avatar = req.files[0].path;
    const avatar = './assets/unknownAvatar';
    const newUsername = req.body.username;
    const newPassword = req.body.password;
    const newEmail = req.body.email;

    const userid = req.session.userid;
    const gender = req.session.gender;
    const birthdate = req.session.birthdate;
    const role = req.session.role;
    const enabled = req.session.enabled;
    const paymentDetails = req.session.paymentDetails;

    if (!newUsername) {
      return res.status(400).json({
        status: 'failed',
        message: 'Missing username',
      });
    }

    if (newPassword.length < 8) {
      return res.status(400).json({
        status: 'failed',
        message: 'Password must be at least 8 characters',
      });
    }

    if (!newEmail) {
      return res.status(400).json({
        status: 'failed',
        message: 'Missing email',
      });
    }

    const updatedResult = await update_user(
      userid,
      newPassword,
      newUsername,
      role,
      newEmail,
      gender,
      birthdate,
      avatar,
      enabled,
      paymentDetails
    );

    if (updatedResult) {
      return res.json({
        status: 'success',
        user: {
          userid: userid,
          role: role,
          avatar: avatar,
        },
      });
    } else {
      return res.status(500).json({
        status: 'failed',
        message: 'Account created but unable to save into the database',
      });
    }
  } catch (err) {
    console.error(err);
    return res.status(500).json({
      status: 'error',
      message: 'An error occurred while processing your request',
    });
  }
});

app.use('/', express.static('static'));

app.listen(8080, () => {
  const currentDate = new Date().toLocaleDateString('en-US', { timeZone: 'Asia/Hong_Kong' });
  const currentTime = new Date().toLocaleTimeString('en-US', { timeZone: 'Asia/Hong_Kong' });
  console.log(`Current date and time: ${currentDate}, ${currentTime}`);
  console.log('Server started at http://127.0.0.1:8080');
});

*/

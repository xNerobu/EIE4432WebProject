// 22080932d ZHENG Kunteng, 22095248d CHENG Kai Yin

import dotenv from 'dotenv';

dotenv.config(); // load the enviroment variables in .env to process.env

if (!process.env.CONNECTION_STR) {
  console.error('CONNECTION_STR is not defined');
  process.exit(1);
}

// if it is defined, export an object containing CONNECTION_STR
export default {
  CONNECTION_STR: process.env.CONNECTION_STR,
};

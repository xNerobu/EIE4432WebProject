// 22080932d ZHENG Kunteng, 22095248d CHENG Kai Yin

import express from 'express';
import multer from 'multer';
import fs from 'fs/promises';
import session from 'express-session';
import {
  validate_user,
  update_user,
  fetch_user,
  fetch_all_user,
  fetch_user_payment_details,
  userid_exist,
} from './userdb.js';

const app = express();
const users = new Map();

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use(
  session({
    secret: '22080932d_22095248d_project',
    resave: false,
    saveUninitialized: false,
    cookie: { httpOnly: true },
  })
);

const route = express.Router();
const form = multer();

//const upload = multer();

route.post('/login', form.none(), async function (req, res) {
  // testing
  //console.log(req);
  //console.log(JSON.stringify(req.body, null, 2));

  /*
  if (users.size === 0) {
    await init_userdb();
  }
  */
  if (req.session.logged) {
    req.session.logged = false; // reset login status
  }

  const user = await validate_user(req.body.userid, req.body.password); // user object

  if (user && user.enabled) {
    req.session.logged = true;
    req.session.userid = user.userid;
    req.session.username = user.username;
    req.session.role = user.role;
    req.session.email = user.email;
    req.session.gender = user.gender;
    req.session.birthdate = user.birthdate;
    req.session.avatar = user.avatar;
    req.session.enabled = user.enabled;
    req.session.paymentDetails = user.paymentDetails; // this will show in the transaction history
    req.session.timestamp = Date.now();

    return res.json({
      status: 'success',
      user: {
        userid: user.userid,
        password: user.password,
        username: user.username,
        role: user.role,
        email: user.email,
        gender: user.gender,
        birthdate: user.birthdate,
        avatar: user.avatar,
      },
    });
  } else if (user && !user.enabled) {
    return res.status(401).json({
      status: 'failed',
      message: `User ${user.userid} is currently disabled`,
    });
  } else {
    return res.status(401).json({
      status: 'failed',
      message: 'Incorrect userid and password',
    });
  }
});

route.post('/logout', async function (req, res) {
  if (req.session.logged) {
    req.session.destroy();
    res.end();
  } else {
    return res.status(401).json({
      status: 'failed',
      message: 'Unauthorized',
    });
  }
});

// Get the information of the currently logged in user
route.get('/me', async function (req, res) {
  const user = await fetch_user(req.session.userid); // change from users.get()
  if (req.session.logged && user) {
    res.json({
      status: 'success',
      user: {
        userid: user.userid,
        password: user.password,
        username: user.username,
        role: user.role,
        email: user.email,
        gender: user.gender,
        birthdate: user.birthdate,
        avatar: user.avatar,
      },
    });
  } else {
    res.status(401).json({
      status: 'failed',
      message: 'Unauthorized',
    });
  }
});

route.post('/register', form.none(), async function (req, res) {
  /*
  // if the database users is empty
  if (users.size === 0) {
    await init_userdb();
  }
  */
  const userid = req.body.userid;
  const password = req.body.password;
  const username = req.body.username;
  const email = req.body.email;
  const gender = req.body.gender;
  const birthdate = req.body.birthdate;
  const role = req.body.role;
  // set default avatar path and enabled
  const avatar = './assets/unknownAvatar.jpg';
  const enabled = true;

  // before processing request, check username and password is empty
  if (!userid || !password) {
    return res.status(400).json({
      status: 'failed',
      message: 'Missing fields',
    });
  }

  // for userid length
  if (userid.length < 2) {
    return res.status(400).json({
      status: 'failed',
      message: 'UserID must be at least 2 characters',
    });
  }

  // change from users.has() to await userid_exist() -lab5
  // original: users.has(username) - lab5
  // for duplicated userid
  if (await userid_exist(userid)) {
    return res.status(400).json({
      status: 'failed',
      message: `UserID ${userid} already exists`,
    });
  }

  // for password length
  if (password.length < 8) {
    return res.status(400).json({
      status: 'failed',
      message: 'Password must be at least 8 characters',
    });
  }
  // check whether repeatPassword match password => do it in static/js/register.js

  // for email checking
  if (!email) {
    return res.status(400).json({
      status: 'failed',
      message: 'Missing email',
    });
  }

  // for gender, it must be &&, otherwise, it will cause logic error.
  if (gender !== 'male' && gender !== 'female') {
    return res.status(400).json({
      status: 'failed',
      message: 'Gender can only be `male` or `female` ',
    });
  }

  // for birthdate checking
  if (!birthdate) {
    return res.status(400).json({
      status: 'failed',
      message: 'Missing birthdate',
    });
  }

  // for role, it must be &&, otherwise, it will cause logic error.
  if (role !== 'user') {
    return res.status(400).json({
      status: 'failed',
      message: 'Role can only be `user`',
    });
  }

  // the case for satisfy all criteria

  // updateUser need to add more fields
  const updatedResult = await update_user(userid, password, username, role, email, gender, birthdate, avatar, enabled);

  if (updatedResult) {
    return res.json({
      status: 'success',
      user: {
        userid: userid,
        password: password,
        username: username,
        role: role,
        email: email,
        gender: gender,
        birthdate: birthdate,
        avatar: avatar,
      },
    });
  } else {
    return res.status(500).json({
      status: 'failed',
      message: 'Account created but unable to save into the database',
    });
  }
});

//const upload = multer({ dest: './uploaded' });
const upload = multer({
  storage: multer.diskStorage({
    destination: function (req, file, cb) {
      cb(null, './static/assets/');
    },
    filename: function (req, file, cb) {
      // fieldname是表单的name值，也就是我们设定的“logo”，
      // originalname是文件上传时的名字，可以根据它获取后缀，
      // encoding，mimetype 我就不详细介绍了，可以自行输出查看。
      //const { fieldname, originalname, encoding, mimetype } = file;
      //const after = originalname.split('.')[1] ? '.' + originalname.split('.')[1] : '.png';
      //cb(null, fieldname + after);
      cb(null, file.originalname);
    },
  }),
});

import path from 'path';
route.post('/profile', upload.single('avatar'), async function (req, res) {
  try {
    console.log(req.body);
    console.log(req.file);

    // original path: static/assets/avatar.png
    const avatar = req.file.path;
    console.log(avatar);

    // new path to database
    const originalFileName = req.file.originalname;
    const newAvatarPath = path.join('./assets/', originalFileName);
    console.log(newAvatarPath);

    //const avatar = req.file.path;
    //console.log(avatar);
    //const avatar = './assets/unknownAvatar.jpg';
    const newUsername = req.body.username;
    const newPassword = req.body.password;
    const newEmail = req.body.email;

    const userid = req.session.userid;
    const gender = req.session.gender;
    const birthdate = req.session.birthdate;
    const role = req.session.role;
    const enabled = req.session.enabled;
    const paymentDetails = req.session.paymentDetails;

    if (!newUsername) {
      return res.status(400).json({
        status: 'failed',
        message: 'Missing username',
      });
    }

    if (newPassword.length < 8) {
      return res.status(400).json({
        status: 'failed',
        message: 'Password must be at least 8 characters',
      });
    }

    if (!newEmail) {
      return res.status(400).json({
        status: 'failed',
        message: 'Missing email',
      });
    }

    const updatedResult = await update_user(
      userid,
      newPassword,
      newUsername,
      role,
      newEmail,
      gender,
      birthdate,
      newAvatarPath,
      enabled,
      paymentDetails
    );

    if (updatedResult) {
      return res.json({
        status: 'success',
        user: {
          userid: userid,
          password: newPassword,
          username: newUsername,
          role: role,
          email: newEmail,
          gender: gender,
          birthdate: birthdate,
          avatar: newAvatarPath,
        },
      });
    } else {
      return res.status(500).json({
        status: 'failed',
        message: 'Account created but unable to save into the database',
      });
    }
  } catch (err) {
    console.error(err);
    return res.status(500).json({
      status: 'error',
      message: 'An error occurred while processing your request',
    });
  }
});

route.get('/users', async function (req, res) {
  const allUsers = await fetch_all_user();
  res.json(allUsers);
});

route.get('/transactions', async function (req, res) {
  if (req.session.logged) {
    const paymentDetails = await fetch_user_payment_details(req.session.userid);
    if (paymentDetails) {
      res.json(paymentDetails);
    } else {
      res.status(404).json({
        status: 'failed',
        message: 'Payment details not found for the user',
      });
    }
  } else {
    // not login
    res.status(401).json({
      status: 'failed',
      message: 'Unauthorized',
    });
  }
});

export default route;

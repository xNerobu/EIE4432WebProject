// 22080932d ZHENG Kunteng, 22095248d CHENG Kai Yin

import express from 'express';
import session from 'express-session';
import mongostore from 'connect-mongo';
import client from './dbclient.js';
import login from './login.js';

const app = express();

app.use(express.urlencoded({ extended: true }));

app.use(
  session({
    secret: '22080932d_22095248d_project',
    resave: false,
    saveUninitialized: true,
    cookie: { httpOnly: true },
    store: mongostore.create({
      client,
      dbName: 'projectdb',
      collectionName: 'session',
    }),
  })
);

// apply login route module to the path /auth for all HTTP methods
app.use('/auth', login);

app.get('/', (req, res) => {
  if (req.session.logged) {
    res.redirect('/transaction-history.html');
  } else {
    res.redirect('/login.html');
  }
});

app.use('/', express.static('static'));

app.listen(8080, () => {
  const currentDate = new Date().toLocaleDateString('en-US', { timeZone: 'Asia/Hong_Kong' });
  const currentTime = new Date().toLocaleTimeString('en-US', { timeZone: 'Asia/Hong_Kong' });
  console.log(`Current date and time: ${currentDate}, ${currentTime}`);
  console.log('Server started at http://127.0.0.1:8080');
});

// 22080932d ZHENG Kunteng, 22095248d CHENG Kai Yin

// this file is the helper module that provides the database connection handle.

import { MongoClient, ServerApiVersion } from 'mongodb';
import config from './config.js';

const connect_uri = config.CONNECTION_STR;

const client = new MongoClient(connect_uri, {
  connectTimeoutMS: 2000,
  serverSelectionTimeoutMS: 2000,
  serverApi: {
    version: ServerApiVersion.v1,
    strict: true,
    deprecationErrors: true,
  },
});

async function connect() {
  try {
    // TODO
    // establish the connection to the database
    await client.connect();
    // to test the connection
    await client.db('projectdb').command({ ping: 1 }); // database name = projectdb

    // system date and time + server address
    const currentDate = new Date().toLocaleDateString('en-US', { timeZone: 'Asia/Hong_Kong' });
    const currentTime = new Date().toLocaleTimeString('en-US', { timeZone: 'Asia/Hong_Kong' });
    console.log(`${currentDate}, ${currentTime}`);
    console.log('Server started at http://127.0.0.1:8080');

    // if successful, print the success msg
    console.log('Successfully connected to the database!');
  } catch (err) {
    // TODO
    // if the connection fails, jump to this catch block
    console.error('Unable to establish connection to the database!');
    process.exit(1); // abort the node process
  }
}

connect().catch(console.dir); // try to connect the database

export default client; // make other module to use this connected database client

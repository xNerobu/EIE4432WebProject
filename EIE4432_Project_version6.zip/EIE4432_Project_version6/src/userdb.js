// 22080932d ZHENG Kunteng, 22095248d CHENG Kai Yin

// this file is to perform CRUD operation to the database

import fs from 'fs/promises';
import client from './dbclient.js';

async function init_db() {
  try {
    // TODO

    const users = client.db('projectdb').collection('users'); // database = projectdb; collection/table = users

    const count = await users.countDocuments(); // to check the collections-users is empty or not

    if (count === 0) {
      // read data from local user database (users.json)
      const data = await fs.readFile('users.json', 'utf-8');
      const usersData = JSON.parse(data); // parse JSON string to JavaScript object

      // insert all user objects to the collections
      const result = await users.insertMany(usersData);

      // shows the number of user records inserted
      console.log(`Added ${result.insertedCount} users`); // insertMany() has the properties: insertedCount
    }
  } catch (err) {
    // TODO
    console.log('Unable to initialize the database!');
  }
}

async function validate_user(userid, password) {
  try {
    if (!userid || !password) {
      return false;
    }

    const users = client.db('projectdb').collection('users');

    // retrieve the user object from users
    const user = await users.findOne({ userid });
    if (user && user.password === password) {
      return user; // Returns an object containing associated user information
    } else {
      return false; // returns false if the username does not exist or password mismatches
    }
  } catch (error) {
    console.log('Unable to fetch from database!');
  }
}

async function update_user(
  userid,
  password,
  username,
  role,
  email,
  gender,
  birthdate,
  avatar,
  enabled,
  paymentDetails
) {
  try {
    const users = client.db('projectdb').collection('users');

    // username as query criterion
    const result = await users.updateOne(
      { userid },
      { $set: { userid, password, username, role, email, gender, birthdate, avatar, enabled, paymentDetails } },
      { upsert: true }
    );

    // check whether it is a update or insert new record(upsert)
    if (result.upsertedCount === 1) {
      //upsert
      console.log('Added 1 user');
      return true;
    } else {
      //update
      console.log('Added 0 user');
      return true;
    }
  } catch (error) {
    console.log('Unable to update the database!');
    return false; // for upsert unsuccessful
  }
}

async function fetch_user(userid) {
  try {
    const users = client.db('projectdb').collection('users');

    const result = await users.findOne({ userid });
    return result;
  } catch (error) {
    console.log('Unable to fetch from database!');
  }
}

async function fetch_all_user() {
  try {
    const users = client.db('projectdb').collection('users');

    const result = await users.find().toArray();
    return result;
  } catch (error) {
    console.log('Unable to fetch all users from database!');
  }
}

async function fetch_user_payment_details(userid) {
  try {
    const users = client.db('projectdb').collection('users');

    const user = await users.findOne({ userid });

    if (user) {
      return user.paymentDetails;
    } else {
      console.log('User not found in the database');
      return null;
    }
  } catch (error) {
    console.log('Unable to fetch user payment details from the database!');
  }
}

async function userid_exist(userid) {
  try {
    const result = await fetch_user(userid);
    return result !== null; // if not null= true ; null=false
  } catch (error) {
    console.log('Unable to fetch from database!');
  }
}

init_db().catch(console.dir);

export { validate_user, update_user, fetch_user, fetch_all_user, fetch_user_payment_details, userid_exist };

// execute this two commands one by one when this js file is initiated.
//validate_user('test1', '12345678').then((res) => console.log('result 1: ', res));

//validate_user('test1', 'wrongpassword').then((res) => console.log('result 2: ', res));
/*
update_user(
  'test3',
  '12345678',
  'test3',
  'user',
  'ttt3@gmail.com',
  'female',
  '2024-11-18',
  './assets/kkkAvatar.png',
  true,
  [
    {
      bookedVenue: '1/F',
      bookedParkingBayNumber: 5,
      bookingType: 'half-day',
      pricingTier: 'vip',
      price: 15,
      paymentMethod: 'AlipayHK',
      paymentTime: '2024-11-30T10:00:00',
      status: 'success',
    },
    {
      bookedVenue: '2/F',
      bookedParkingBayNumber: 10,
      bookingType: 'full-day',
      pricingTier: 'regular',
      price: 20,
      paymentMethod: 'Wechat Pay',
      paymentTime: '2024-11-29T15:30:00',
      status: 'success',
    },
  ]
).then((res) => console.log(res)); // change gender to female, enable to true
*/
//update_user('22080932', '22080932', 'user', false).then((res) => console.log(res));

//fetch_user('anyone').then((res) => console.log(res));

//fetch_user('22080932').then((res) => console.log(res));

//username_exist('anyone').then((res) => console.log(res));

//username_exist('22080932').then((res) => console.log(res));

//fetch_all_user().then((res) => console.log(res));

//fetch_user_payment_details('test3').then((res) => console.log(res));

// 22080932d ZHENG Kunteng, 22095248d CHENG Kai Yin

document.addEventListener('DOMContentLoaded', function () {
  const registerButton = document.getElementById('register-button');

  registerButton.addEventListener('click', function () {
    const userid = document.getElementById('userid').value;
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    const repeatPassword = document.getElementById('repeatPassword').value;
    const email = document.getElementById('email').value;
    const gender = document.getElementById('gender').value;
    const birthdate = document.getElementById('birthdate').value;
    //const role = document.querySelector('input[name="role"]:checked');
    const role = document.getElementById('role').value;

    if (!userid || !username || !password) {
      alert('Userid, username and password cannot be empty');
      return;
    }

    if (password !== repeatPassword) {
      alert('Password mismatch!');
      return;
    }

    if (!email) {
      alert('Please enter a email!');
      return;
    }

    if (gender === 'none') {
      alert('Please select your gender');
      return;
    }

    if (!birthdate) {
      alert('Please enter your birthdate');
      return;
    }

    if (role === 'none') {
      alert('Please select your role');
      return;
    }
    // Use the FormData object to add the user-filled information to the form data in the form of key-value pairs
    const formData = new FormData();
    formData.append('userid', userid);
    formData.append('username', username);
    formData.append('password', password);
    formData.append('email', email);
    formData.append('gender', gender);
    formData.append('birthdate', birthdate);
    formData.append('role', role);
    formData.append('enabled', true);
    formData.append('avatar', './assets/unknownAvatar.jpg');

    fetch('/auth/register', {
      method: 'POST',
      body: formData,
    })
      .then((response) => {
        return response.json();
      })
      .then((data) => {
        if (data.status === 'success') {
          console.log(data); // testing
          alert(`Welcome, ${data.user.userid}!\nYou can login with your account now!`);
          window.location.href = '/login.html';
        } else {
          alert(data.message);
        }
      })
      .catch((error) => {
        alert('Unknown error');
      });
  });
});

const parkingLayout = document.getElementById('parking-layout');
const priceElement = document.getElementById('price');
const textElement = document.getElementById('text');
const floorSelect = document.getElementById('floor-select');
const parkingForm = document.getElementById('parking-form');

let selectedFloor = '1/F'; // Set initial floor to 1/F
let selectedSpot = null;
let price = 0;

// Fetch parking data for a specific date from localStorage
function loadParkingData(date) {
  const storedData = localStorage.getItem('parkingData');
  //localStorage.removeItem('parkingData');
  console.log(storedData);
  alert('进来loadParkingData fucntion');

  if (storedData) {
    window.parkingData = JSON.parse(storedData);
    alert('进来第一个if');
  } else {
    alert('进来fetch parkingspots');
    // Use default parking data if no data is stored in localStorage
    fetch('parkingspots.json')
      .then((response) => response.json())
      .then((data) => {
        window.parkingData = data;
        localStorage.setItem('parkingData', JSON.stringify(data)); // Save it to localStorage
        renderParking(selectedFloor, date); // Call renderParking initially after data is loaded
      })
      .catch((error) => {
        console.error('Error loading parking data:', error);
        alert('Error loading parking data!');
      });
  }
}

// Save booking status for a specific date
function saveBooking(date, spot) {
  const bookings = JSON.parse(localStorage.getItem('bookings')) || {};

  if (!bookings[date]) {
    bookings[date] = {}; // Initialize date entry if not exists
  }

  bookings[date][spot.id] = true; // Mark the spot as booked

  localStorage.setItem('bookings', JSON.stringify(bookings)); // Save updated bookings to localStorage
}

// Load parking data on page load
loadParkingData();

// Render parking spots for the selected floor and selected date
function renderParking(floor, date) {
  if (!window.parkingData || !window.parkingData[floor]) {
    console.error('No data for the selected floor:', floor);
    return;
  }

  parkingLayout.innerHTML = ''; // Clear previous layout

  const spotsPerRow = 5; // Define the number of spots per row
  const spotWidth = 60; // Width of each parking spot
  const spotHeight = 40; // Height of each parking spot
  const padding = 10; // Padding between spots

  // Get the booked spots for the selected date from localStorage
  const bookings = JSON.parse(localStorage.getItem('bookings')) || {};
  const bookedSpots = bookings[date] || {}; // Get booked spots for this date

  window.parkingData[floor].forEach((spot, index) => {
    // Check if the spot is booked for the selected date
    const isBooked = bookedSpots[spot.id] || false;

    // Calculate column and row based on the index (ID - 1)
    const column = index % spotsPerRow;
    const row = Math.floor(index / spotsPerRow);

    // Calculate X and Y positions based on column and row
    const x = column * (spotWidth + padding) + 50; // X-position for column
    const y = row * (spotHeight + padding) + 50; // Y-position for row

    // Create the parking spot rectangle
    const rect = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
    rect.setAttribute('width', spotWidth);
    rect.setAttribute('height', spotHeight);
    rect.setAttribute('x', x);
    rect.setAttribute('y', y);
    rect.setAttribute('class', isBooked ? 'booked' : spot.type === 'regular' ? 'parking-spot' : 'vip-spot');
    rect.addEventListener('click', () => selectSpot(spot));

    // Create the text element to display the parking spot ID
    const text = document.createElementNS('http://www.w3.org/2000/svg', 'text');
    text.setAttribute('x', x + spotWidth / 2); // Center the text horizontally
    text.setAttribute('y', y + spotHeight / 2); // Center the text vertically
    text.setAttribute('fill', 'grey'); // Set the text color to grey
    text.setAttribute('text-anchor', 'middle'); // Center-align the text
    text.setAttribute('dy', '.35em'); // Vertically center the text
    text.textContent = spot.id;

    // Append the rectangle and the text to the parking layout
    parkingLayout.appendChild(rect);
    parkingLayout.appendChild(text);
  });
}

// Handle spot selection
function selectSpot(spot) {
  if (spot.booked) return;
  selectedSpot = spot;
  updatePrice();
  textElement.textContent = `Selected Spot: ${spot.id}`;
}

// Update price based on selected duration
function updatePrice() {
  const duration = document.querySelector('input[name="duration"]:checked').value;
  price = selectedSpot.type === 'regular' ? (duration === 'full-day' ? 20 : 10) : duration === 'full-day' ? 30 : 15;
  priceElement.textContent = price;
}

// Reset selection
function reset() {
  selectedSpot = null;
  price = 0;
  priceElement.textContent = price;
  textElement.textContent = 'Click a parking bay to book';
}
document.getElementById('reset').addEventListener('click', () => {
  reset();
});

// Floor selection change event (for dropdown)
floorSelect.addEventListener('change', () => {
  selectedFloor = floorSelect.value;
  renderParking(selectedFloor); // Re-render parking layout for selected floor
  reset();
});

// Handle date selection change event
document.getElementById('parking-date').addEventListener('change', (event) => {
  const selectedDate = event.target.value;
  renderParking(selectedFloor, selectedDate); // Re-render parking layout for the selected date
  reset(); // Reset selected spot and price
});

// Confirm payment
parkingForm.addEventListener('submit', (e) => {
  e.preventDefault();

  const selectedDate = document.getElementById('parking-date').value;

  if (!selectedSpot) {
    alert('Please select a parking spot first!');
    return;
  }

  // Mark the spot as booked for the selected date
  saveBooking(selectedDate, selectedSpot);

  // Update the parking layout and reflect the booked spot
  renderParking(selectedFloor, selectedDate);

  alert(`Spot ${selectedSpot.id} booked successfully for ${selectedDate}!`);
  reset();
});

// Set the default value of the date picker to today's date
document.addEventListener('DOMContentLoaded', () => {
  const dateInput = document.getElementById('parking-date');
  const today = new Date();

  // Format the date as YYYY-MM-DD
  const formattedDate = today.toISOString().split('T')[0];

  // Set the default value to today
  dateInput.value = formattedDate;

  // Render parking layout for the selected floor and the default date
  renderParking('1/F');
});

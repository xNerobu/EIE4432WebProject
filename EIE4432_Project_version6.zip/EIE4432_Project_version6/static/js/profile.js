// 22080932d ZHENG Kunteng, 22095248d CHENG Kai Yin

document.addEventListener('DOMContentLoaded', function () {
  const registerButton = document.getElementById('update-button');

  registerButton.addEventListener('click', function () {
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    const repeatPassword = document.getElementById('repeatPassword').value;
    const email = document.getElementById('email').value;
    const fileUpload = document.getElementById('file-upload').files[0];

    if (!username) {
      alert('Username cannot be empty');
      return;
    }

    if (!password) {
      alert('Password cannot be empty');
      return;
    }

    if (password !== repeatPassword) {
      alert('Password mismatch!');
      return;
    }

    if (!email) {
      alert('Please enter a email!');
      return;
    }

    if (!fileUpload) {
      alert('Please upload the image file for avatar!');
      return;
    }

    console.log(fileUpload);
    alert('可看fileUpload');

    // Use the FormData object to add the user-filled information to the form data in the form of key-value pairs
    const formData = new FormData();

    formData.append('username', username);
    formData.append('password', password);
    formData.append('email', email);
    formData.append('avatar', fileUpload);

    console.log(formData);

    fetch('/auth/profile', {
      method: 'POST',
      body: formData,
    })
      .then((response) => {
        //alert('come to response');

        console.log(response);
        if (!response.ok) {
          throw new Error('Network response was not ok');
        }
        return response.json();
      })
      .then((data) => {
        if (data.status === 'success') {
          console.log(data); // testing
          alert('User profile updated successfully! Logout and login again!');

          // automatically logout and ask user to login again.
          fetch('/auth/logout', {
            method: 'POST',
          })
            .then(() => {
              window.location.href = '/login.html';
            })
            .catch((error) => {
              console.error('Error: ', error);
              alert('Error for logging out, please try again');
            });
        } else {
          alert(data.message);
        }
      })
      .catch((error) => {
        console.error('Error arise: ', error);
        alert('Unknown error');
      });
  });

  fetch('/auth/me', {
    method: 'GET',
  })
    .then((response) => {
      return response.json();
    })
    .then((data) => {
      if (data.status === 'success') {
        // display avatar and userid in nav bar
        document.getElementById('user-id').innerText = data.user.userid;
        document.getElementById('avatar');
        const userAvatar = document.getElementById('avatar');
        userAvatar.src = data.user.avatar; // Fill the path of the avatar into src

        // to show current user profile information
        document.getElementById('userid').innerText = data.user.userid;
        document.getElementById('oldpassword').innerText = data.user.password;
        document.getElementById('oldusername').innerText = data.user.username;
        document.getElementById('profileImage').src = data.user.avatar;
        document.getElementById('oldemail').innerText = data.user.email;
        document.getElementById('gender').innerText = data.user.gender;
        document.getElementById('birthdate').innerText = data.user.birthdate;

        // Check if whether it is an admin to display a specific page
        if (data.user.role !== 'admin') {
          // Hide admin-only links
          const adminLinks = document.querySelectorAll('.admin-link');
          adminLinks.forEach((link) => {
            link.style.display = 'none';
          });
        }
      } else {
        // if the user direclty go to index.html without login
        alert('Please login');
        window.open('/login.html', '_self');
      }
    });
  // for logout button
  document.getElementById('logout-button').addEventListener('click', function () {
    const confirmLogout = confirm('Confirm to logout?');
    if (confirmLogout) {
      fetch('/auth/logout', {
        method: 'POST',
      })
        .then(() => {
          window.location.href = '/login.html';
        })
        .catch((error) => {
          console.error('Error: ', error);
          alert('Error for logging out, please try again');
        });
    }
  });
});

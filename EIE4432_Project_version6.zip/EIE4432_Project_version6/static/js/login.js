// 22080932d ZHENG Kunteng, 22095248d CHENG Kai Yin

document.addEventListener('DOMContentLoaded', function () {
  const loginButton = document.getElementById('login-button');
  const rememberUserIdCheckbox = document.getElementById('rememberUserId'); // checkbox
  const useridInput = document.getElementById('userid'); // get userid inputbox

  // check whether the local storage save the userid
  const rememberedUserId = localStorage.getItem('rememberedUserId');
  if (rememberedUserId) {
    useridInput.value = rememberedUserId; // Fill the most recent user id into the userid input box
    rememberUserIdCheckbox.checked = true; // check “Remember UserID” checkbox at the same time
  }

  loginButton.addEventListener('click', function () {
    const userid = useridInput.value;
    const password = document.getElementById('password').value;
    const rememberUserId = rememberUserIdCheckbox.checked; // if checked, it is true

    if (!userid || !password) {
      alert('UserID and password cannot be empty.');
      return;
    }

    //This FormData object is then sent to the server's /auth/login route by using the fetch API.
    //In this case, the userid and password are sent to the server as form data along with the POST request,
    //so that the server can get these values for user authentication.

    const formData = new FormData(); // The form data is assembled into an object of key-value pairs
    formData.append('userid', userid);
    formData.append('password', password);

    // Choice to remember userID
    if (rememberUserId) {
      // Save the UserID in local storage or cookies for future use
      localStorage.setItem('rememberedUserId', userid);
    } else {
      // Clear the saved UserID if not remembered
      localStorage.removeItem('rememberedUserId');
    }

    // submit the form data to /auth/login
    fetch('/auth/login', {
      method: 'POST',
      body: formData,
    })
      .then((response) => {
        return response.json();
      })
      .then((data) => {
        if (data.status === 'success') {
          alert(`Logged as ${data.user.userid} (${data.user.role})`);
          window.location.href = '/index.html';
        } else {
          alert(data.message);
        }
      })
      .catch((error) => {
        alert('Unknown error');
      });
  });
});

// 22080932d ZHENG Kunteng, 22095248d CHENG Kai Yin

document.addEventListener('DOMContentLoaded', function () {
  fetch('/auth/me', {
    method: 'GET',
  })
    .then((response) => {
      return response.json();
    })
    .then((data) => {
      if (data.status === 'success') {
        // display avatar and userid in nav bar
        document.getElementById('user-id').innerText = data.user.userid;
        document.getElementById('avatar');
        const userAvatar = document.getElementById('avatar');
        userAvatar.src = data.user.avatar; // Fill the path of the avatar into src

        // Check if whether it is an admin to display a specific page
        if (data.user.role !== 'admin') {
          // Hide admin-only links
          const adminLinks = document.querySelectorAll('.admin-link');
          adminLinks.forEach((link) => {
            link.style.display = 'none';
          });
        }

        // Fetch all users data
        fetch('/auth/users')
          .then((response) => response.json())
          .then((users) => {
            const tableBody = document.querySelector('table tbody');
            tableBody.innerHTML = ''; // Clear existing rows

            users.forEach((user) => {
              const row = `
                <tr>
                  <td>${user.userid}</td>
                  <td>${user.username}</td>
                  <td>${user.role}</td>
                  <td>${user.email}</td>
                  <td>${user.gender}</td>
                  <td>${user.birthdate}</td>
                  
                </tr>
              `;
              // <td><button class="btn btn-primary">Edit</button></td>
              tableBody.insertAdjacentHTML('beforeend', row);
            });
          })
          .catch((error) => console.error('Error fetching users:', error));
      } else {
        // if the user direclty go to index.html without login
        alert('Please login');
        window.open('/login.html', '_self');
      }
    });
  // for logout button
  document.getElementById('logout-button').addEventListener('click', function () {
    const confirmLogout = confirm('Confirm to logout?');
    if (confirmLogout) {
      fetch('/auth/logout', {
        method: 'POST',
      })
        .then(() => {
          window.location.href = '/login.html';
        })
        .catch((error) => {
          console.error('Error: ', error);
          alert('Error for logging out, please try again');
        });
    }
  });
});

// 22080932d ZHENG Kunteng, 22095248d CHENG Kai Yin
document.addEventListener('DOMContentLoaded', function () {
  fetch('/auth/me', {
    method: 'GET',
  })
    .then((response) => {
      return response.json();
    })
    .then((data) => {
      if (data.status === 'success') {
        // display avatar and userid in nav bar
        document.getElementById('user-id').innerText = data.user.userid;
        document.getElementById('avatar');
        document.getElementById('USERID').innerText = data.user.userid;
        const userAvatar = document.getElementById('avatar');
        userAvatar.src = data.user.avatar; // Fill the path of the avatar into src

        // Check if whether it is an admin to display a specific page
        if (data.user.role !== 'admin') {
          // Hide admin-only links
          const adminLinks = document.querySelectorAll('.admin-link');
          adminLinks.forEach((link) => {
            link.style.display = 'none';
          });

          fetch('/auth/transactions')
            .then((response) => response.json())
            .then((transactionData) => {
              const tbody = document.querySelector('tbody');
              tbody.innerHTML = '';
              //console.log(transactionData);

              console.log(Array.isArray(transactionData));

              transactionData.forEach((transaction) => {
                const row = document.createElement('tr');
                row.innerHTML = `
                <td>${transaction.bookedVenue}</td>
                <td>${transaction.bookedParkingBayNumber}</td>
                <td>${transaction.bookingType}</td>
                <td>${transaction.pricingTier}</td>
                <td>${transaction.price}</td>
                <td>${transaction.paymentMethod}</td>
                <td>${transaction.paymentTime}</td>
                <td>${transaction.status}</td>
              `;
                tbody.appendChild(row);
              });
            })
            .catch((error) => {
              console.error('Error fetching transaction data:', error);
            });
        }
      } else {
        alert('Please login');
        window.open('/login.html', '_self');
      }
    });

  // Logout button functionality
  document.getElementById('logout-button').addEventListener('click', function () {
    const confirmLogout = confirm('Confirm to logout?');
    if (confirmLogout) {
      fetch('/auth/logout', {
        method: 'POST',
      })
        .then(() => {
          window.location.href = '/login.html';
        })
        .catch((error) => {
          console.error('Error: ', error);
          alert('Error for logging out, please try again');
        });
    }
  });
});
